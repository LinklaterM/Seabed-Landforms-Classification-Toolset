# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-plain.py
# Created on: 2019-11-15 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: LANDFORMSplain <DEM><BBPI_threshold><FBPI_threshold><WinSize_BBPI><WinSize_FBPI><PolyThreshold>
# Description: LANDFORMS step 9 OPTIONAL plain landforms
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
DEM = arcpy.GetParameterAsText(0)
BBPI_threshold = arcpy.GetParameterAsText(1)
if BBPI_threshold == '#' or not BBPI_threshold:
    BBPI_threshold = "-60;60" # provide a default value if unspecified
FBPI_threshold = arcpy.GetParameterAsText(2)
if FBPI_threshold == '#' or not FBPI_threshold:
    FBPI_threshold = "-60;60" # provide a default value if unspecified
WinSize_BBPI = arcpy.GetParameterAsText(3)
if WinSize_BBPI == '#' or not WinSize_BBPI:
    WinSize_BBPI = "150" # provide a default value if unspecified
WinSize_FBPI = arcpy.GetParameterAsText(4)
if WinSize_FBPI == '#' or not WinSize_FBPI:
    WinSize_FBPI = "27" # provide a default value if unspecified
PolyThreshold = arcpy.GetParameterAsText(5)

bth = BBPI_threshold.split(";")
fth = FBPI_threshold.split(";")

d = datetime.datetime.now()
f = open('CurrentSession_Settings_PLAIN_' + d.strftime('%Y%m%d%H%M') + '.txt',"w")
s1 = 'Step7:'
s2 = '	DEM:' + DEM
s3 = '	Broad BPI Threshold: [' + bth[0] + ',' + bth[1] + ']'
s4 = '	Fine BPI Threshold: [' + fth[0] + ',' + fth[1] + ']'
s5 = '	Broad BPI Window Size: ' + WinSize_BBPI
s6 = '	Fine BPI Window Size: ' + WinSize_FBPI
s = s1 + '\n' + s2 + '\n' + s3 + '\n' + s4 + '\n' + s5 + '\n' + s6 + '\n'

arcpy.AddMessage(s2)
arcpy.AddMessage(s3)
arcpy.AddMessage(s4)
arcpy.AddMessage(s5)
arcpy.AddMessage(s6)

f.write(s)

# Local variables
union_poly = arcpy.env.workspace + os.sep + "surf_elem_plain_union"
union_poly_d = arcpy.env.workspace + os.sep + "surf_elem_plain"
union_poly_dex = arcpy.env.workspace + os.sep + "surf_elem_plain_union_dex"
union_poly_dex_layer = "union_poly_dex_layer"

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Process: SURFEL Broad TPI
arcpy.AddMessage('Calculate Broad TPI ... ')
arcpy.SURFELbroadbpi(DEM, WinSize_BBPI, BBPI_threshold)
	
# Process: SURFEL Fine TPI
arcpy.AddMessage('Calculate Fine TPI ... ')
arcpy.SURFELfinebpi(DEM, WinSize_FBPI, FBPI_threshold)

# Process: PLAIN union surface elements 
arcpy.AddMessage('Create Surface Elements union ... ')
arcpy.PLAINunionsurfel()

fc = union_poly
if arcpy.Exists(fc):
	# Process: PLAIN union surface elements
	arcpy.AddMessage('Calculate Surface Elements ... ')
	arcpy.PLAINsurfel(union_poly)
	# Process: PLAIN simplify surface elements
	arcpy.AddMessage('Simplify Surface Elements ... ')
	arcpy.PLAINsumse(union_poly)

	# ELIMINATE SMALL POLYGONS (Optional)
	if PolyThreshold:
		# Process: Multi to Single
		arcpy.AddMessage('	Multi to Single...')
		arcpy.MultipartToSinglepart_management(union_poly,union_poly_dex)

		where_clause = "Shape_Area <= " + PolyThreshold
		s3 = '	Eliminating small polygons <= ' + PolyThreshold + 'm2'
		
		# Process: Make Feature Layer
		arcpy.MakeFeatureLayer_management(union_poly_dex,union_poly_dex_layer)
		
		# Process: Select Layer by Attribute
		arcpy.SelectLayerByAttribute_management(union_poly_dex_layer,"NEW_SELECTION",where_clause)
		
		# Process: Eliminate small polygons
		arcpy.Eliminate_management(union_poly_dex_layer, union_poly,"LENGTH")
	else:
		s3 = '	Not eliminating small polygons!'


	# Process: Dissolve
	arcpy.AddMessage('Dissolving...')
	arcpy.Dissolve_management(union_poly,union_poly_d,["SURF_EL", "PLAIN"])

else:
	arcpy.AddMessage('Need to calculate Surface Elements manually!')


arcpy.AddMessage(s3)
arcpy.AddMessage(' ')

# Write to settings log file
f.write(s3 + '\n')
f.close()

# Add to map
nl = arcpy.mapping.Layer(union_poly_d)
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Plain landforms.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Plain landforms.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)
	
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()

