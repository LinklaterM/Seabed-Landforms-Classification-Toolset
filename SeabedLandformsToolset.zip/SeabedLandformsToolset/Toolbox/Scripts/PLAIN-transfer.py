# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# PLAIN-transfer.py
# Created on: 2020-03-12 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: PLAINtransfer <RegLabel>
# Description: LANDFORMS step 10 OPTIONAL transfer plain files
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)

RegLabel = InputFeatureClass
arcpy.AddMessage('   Region Label: ' + RegLabel)
output_dir = Base_Dir + os.sep + "PLAIN_" + RegLabel + ".gdb"

if os.path.exists(output_dir) == False:
	arcpy.CreateFileGDB_management(Base_Dir,"PLAIN_" + RegLabel + ".gdb")
	arcpy.AddMessage('   create out: ' + output_dir)

# Change name settings file
logfile = ''
for fl_all in os.listdir(Base_Dir):
	if fl_all.startswith("CurrentSession_Settings_PLAIN_"):
		logfile = fl_all

if logfile:
	ls = logfile.split("_")
	nls = RegLabel + '_' + "_".join(ls[1:len(ls)])

	arcpy.AddMessage('Settings (old): ' + logfile)
	arcpy.AddMessage('Settings (new): ' + nls)

	os.rename(logfile, nls)

arcpy.AddMessage('Transfer results for ' + RegLabel)

# From Working (main)
u_list = ['surf_elem_plain']
for u in u_list:
	if arcpy.Exists(arcpy.env.workspace + os.sep + u):
		arcpy.AddMessage('	' + u + ' to ' + RegLabel + '_' + u)
		arcpy.Copy_management(arcpy.env.workspace + os.sep + u, \
				output_dir + os.sep + RegLabel + "_" + u)
	else:
		arcpy.AddMessage('	No ' + u)

# Tidyup
arcpy.LANDFORMSclear()
arcpy.AddMessage('Cleaning Scratch/Working gdbs')

sys.exit()
