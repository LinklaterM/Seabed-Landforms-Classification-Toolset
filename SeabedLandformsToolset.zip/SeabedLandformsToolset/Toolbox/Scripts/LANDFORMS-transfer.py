# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-transfer.py
# Created on: 2020-03-12 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: LANDFORMStransfer <RegLabel>
# Description: LANDFORMS step 8 transfer landform files
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Define Spatial Reference
sr = arcpy.Describe(arcpy.env.workspace + os.sep + "final_landforms").SpatialReference

# Script arguments
RegLabel = arcpy.GetParameterAsText(0)

arcpy.AddMessage('   Region Label: ' + RegLabel)
output_dir = Base_Dir + os.sep + "LANDFORM_" + RegLabel + ".gdb"

if os.path.exists(output_dir) == False:
	arcpy.CreateFileGDB_management(Base_Dir,"LANDFORM_" + RegLabel + ".gdb")
	arcpy.AddMessage('   create out: ' + output_dir)

	arcpy.CreateFeatureDataset_management(output_dir,"intermediate",sr)
	
# Change name of settings file
logfile = ''
for fl_all in os.listdir(Base_Dir):
	if fl_all.startswith("CurrentSession_Settings_LANDFORMS_"):
		logfile = fl_all

if logfile:
	ls = logfile.split("_")
	nls = RegLabel + '_' + "_".join(ls[1:len(ls)])

	arcpy.AddMessage('Settings (old): ' + logfile)
	arcpy.AddMessage('Settings (new): ' + nls)

	os.rename(logfile, nls)

arcpy.AddMessage('Transfer results for ' + RegLabel)

# From Working (reclass)
# Transfer and Delete
u_list = ['surf_elem_D','vrm_noise_corr', \
	'study_area_Er_all_rug_classes','study_area_Er_rug_outcrops']
for u in u_list:
	if arcpy.Exists(arcpy.env.workspace + os.sep + u):
		arcpy.AddMessage('	' + u + ' to ' + RegLabel + '_' + u)
		arcpy.FeatureClassToFeatureClass_conversion(arcpy.env.workspace + os.sep + u, \
				output_dir + os.sep + "intermediate", \
				RegLabel + "_" + u)
		arcpy.Delete_management(u)
	else:
		arcpy.AddMessage('	No ' + u)
		
# From Working (main)
fc_list = arcpy.ListFeatureClasses()
# Delete
u_list=[]
for fc in fc_list:
	if "study_area" in fc:
		u_list.append(fc)	

for u in u_list:
	arcpy.Delete_management(u)


# Transfer
for u in fc_list:
	if arcpy.Exists(arcpy.env.workspace + os.sep + u):
		arcpy.AddMessage('	' + u + ' to ' + RegLabel + '_' + u)
		arcpy.Copy_management(arcpy.env.workspace + os.sep + u, \
				output_dir + os.sep + RegLabel + "_" + u)
	else:
		arcpy.AddMessage('	No ' + u)

# Tidyup
arcpy.LANDFORMSclear()
arcpy.AddMessage('Cleaning Scratch/Working gdbs')

sys.exit()
