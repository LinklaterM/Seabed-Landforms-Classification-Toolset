# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LAND-bound-buffer.py
# Created on: 2020-06-15 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: LANDboundbuffer <buffered_poly><unbuffered_poly>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)
OutputFeatureClass = arcpy.GetParameterAsText(1)
if OutputFeatureClass == '#' or not OutputFeatureClass:
    OutputFeatureClass = arcpy.env.workspace + os.sep + "buff_remove" # provide a default value if unspecified
    
# Local variables:
buff_sort = arcpy.env.scratchWorkspace + os.sep + "buff_sort"
buff_sort_layer = "buff_sort_layer"

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Process: Sort
arcpy.AddMessage('Sort Layer by shape area...')
arcpy.Sort_management(InputFeatureClass, buff_sort,[["Shape_Area", "DESCENDING"]]) 

# Process: Make Feature Layer
arcpy.AddMessage('Make Feature Layer...')
arcpy.MakeFeatureLayer_management(buff_sort,buff_sort_layer)

# Process: Select Layer by Attributes
arcpy.AddMessage('Select Layer by attributes...')
where_clause="OBJECTID>1"
arcpy.SelectLayerByAttribute_management(buff_sort_layer,"NEW_SELECTION",where_clause)

# Process: Copy Features
arcpy.AddMessage('Copy Features...')
arcpy.CopyFeatures_management(buff_sort_layer,OutputFeatureClass)

sys.exit()
