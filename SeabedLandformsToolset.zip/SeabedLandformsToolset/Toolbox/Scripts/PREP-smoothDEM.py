# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# PREP-smoothDEM.py
# Created on: 2020-07-02 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: PREPsmoothDEM <DEM><RegLabel><N_iter>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
DEM = arcpy.GetParameterAsText(0)
RegLabel = arcpy.GetParameterAsText(1)
N_iter = arcpy.GetParameterAsText(2)

arcpy.AddMessage('   DEM (in): ' + DEM)

isplit = DEM.split("\\")
xyz = isplit[len(isplit)-1]

# Set Raster Geoprocessing environments
arcpy.env.cellSize = DEM
arcpy.env.snapRaster = DEM
arcpy.env.mask = DEM

# Local variables:
DEMmm = arcpy.env.scratchWorkspace + os.sep + xyz + "_mm"
DEMmmI = arcpy.env.scratchWorkspace + os.sep + xyz + "_mmI"
DEMmmIs = arcpy.env.scratchWorkspace + os.sep + xyz + "_mmIs"
DEMmms = arcpy.env.scratchWorkspace + os.sep + xyz + "_mms"

if RegLabel:
	output_dir = Base_Dir + os.sep + "DEM_" + RegLabel + ".gdb"
	DEMout = output_dir + os.sep + xyz + "_s" + N_iter
else:
	DEMout = DEM + "_s" + N_iter
	
arcpy.AddMessage('   DEM (out): ' + DEMout)

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Create output gdb if required
if RegLabel:
	if os.path.exists(output_dir) == False:
		##CreateFileGDB_management (out_folder_path, out_name, {out_version}) 
		arcpy.CreateFileGDB_management(Base_Dir,"DEM_" + RegLabel + ".gdb")
		arcpy.AddMessage('   create out gdb: ' + output_dir)

# Process: Times
##Times_sa (in_raster_or_constant1, in_raster_or_constant2, out_raster) 
arcpy.AddMessage('Convert to mm...')
outTimes = Times(DEM,1000)
outTimes.save(DEMmm)

# Process: Int
arcpy.AddMessage('Convert to integer...')
outInt = Int(DEMmm)
outInt.save(DEMmmI)

# Iterative smoothing
for num in range(1,int(N_iter)+1):
	arcpy.AddMessage('	iter: ' + str(num))
	if num == 2:
		DEMmmI = DEMmmIs
		DEMmmIs = DEMmmIs + str(num)
	elif num > 2:
		DEMmmI = DEMmmIs[0:len(DEMmmIs)-1] + str(num-1)
		DEMmmIs = DEMmmIs[0:len(DEMmmIs)-1] + str(num)
		
	# Process: Smooth DEM
	##FocalStatistics_sa (in_raster, {neighborhood}, {statistics_type}, {ignore_nodata}, 
	##	out_raster) 
	arcpy.AddMessage('Smooth DEM...')
	neighbourhood = NbrRectangle(3, 3, "CELL")
	outSmooth = FocalStatistics(DEMmmI,neighbourhood,"MEDIAN","")
	outSmooth.save(DEMmmIs)

# Process: Float
arcpy.AddMessage('Convert to float...')
outFloat = Float(DEMmmIs)
outFloat.save(DEMmms)

# Process: Divide
arcpy.AddMessage('Convert to m...')
outDiv = Divide(DEMmms,1000)
outDiv.save(DEMout)

# Tidy up
fc = DEMout
if arcpy.Exists(fc):
	ds_list=[DEMmm, DEMmmI, DEMmmIs, DEMmms]
	for ds in ds_list:
		arcpy.Delete_management(ds)
		
# Add to map
nl = arcpy.mapping.Layer(DEMout)
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "DEM.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "DEM.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)

arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()
