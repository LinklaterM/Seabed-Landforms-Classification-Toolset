# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# SURFEL-sum-se.py
# Created on: 2019-11-14 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: SURFELsumse <union_poly>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)

union_poly = InputFeatureClass
arcpy.AddMessage('   reclass_Union: ' + union_poly)

# Local variables:
expression = "myCalc(!SURF_EL!)"
codeblock = """def myCalc(old):
	if old == "Slope":
		return "Slope"
	elif old == "BS Low Smooth" or old == "FS Low Smooth":
		return "Smooth Low"
	elif old == "Plane Smooth":
		return "Smooth Flat"
	elif old == "FS High Smooth" or old == "BS High Smooth":
		return "Smooth Outcrop"
	elif old == "FS High Rugose" or old == "BS High Rugose":
		return "Rugose Outcrop Peak"
	elif old == "Plane Rugose" or old == "BS Low Rugose":
		return "Rugose Outcrop"
	elif old == "FS Low Rugose":
		return "Rugose Low"
	else:
		return "" """

# Process: Add Field
arcpy.AddField_management(union_poly,"SUM_SE","TEXT")

# Process: Calculate Field
arcpy.CalculateField_management(union_poly,"SUM_SE",expression,"PYTHON_9.3",codeblock)

sys.exit()

