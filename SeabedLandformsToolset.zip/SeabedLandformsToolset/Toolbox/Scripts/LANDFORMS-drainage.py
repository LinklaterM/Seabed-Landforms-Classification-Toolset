# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-drainage.py
# Created on: 2020-02-18 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: LANDFORMSdrainage <DEM>
# Description: LANDFORMS step 4 OPTIONAL drainage
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)

dem = InputFeatureClass
arcpy.AddMessage('   DEM: ' + dem)

# Local variables:
demFill = arcpy.env.scratchWorkspace + os.sep + "demFill"
FlowDir = arcpy.env.scratchWorkspace + os.sep + "FlowDir"
FlowAccum = arcpy.env.scratchWorkspace + os.sep + "FlowAccum"
FlowAccum10 = arcpy.env.scratchWorkspace + os.sep + "FlowAccum10"
drain = arcpy.env.workspace + os.sep + "drainage"

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Process: Fill
arcpy.AddMessage('Fill DEM...')
outFill = Fill(dem)
outFill.save(demFill)

# Process: Flow Direction
arcpy.AddMessage('Calculate Flow Direction...')
outFlowDirection = FlowDirection(demFill)
outFlowDirection.save(FlowDir)

# Process: Flow accumulation
arcpy.AddMessage('Calculate Flow Accumulation...')
outFlowAccum = FlowAccumulation(FlowDir)
outFlowAccum.save(FlowAccum)

# Process: Log10
arcpy.AddMessage('Calculate Log10...')
outLog10 = Log10(FlowAccum)
outLog10.save(FlowAccum10)

# Process: Clip data
arcpy.AddMessage('Clip Flow Data...')
outCon = Con(Raster(FlowAccum10) >= 2,Raster(FlowAccum10))
outCon.save(drain)
		
# Add to map
nl = arcpy.mapping.Layer(drain)
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()
