# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-final.py
# Created on: 2021-01-29 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: LANDFORMSfinal <prelim_landforms><Polygon Threshold><is_iter>
# Description: LANDFORMS step 7 final landforms
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeature = arcpy.GetParameterAsText(0)
PolyThreshold = arcpy.GetParameterAsText(1)
is_iter = arcpy.GetParameterAsText(2)

arcpy.AddMessage(' ')
arcpy.AddMessage('Input Feature Layer: ' + InputFeature)

# Write to settings log file
logfile = ''
for fl_all in os.listdir(Base_Dir):
	if fl_all.startswith("CurrentSession"):
		logfile = fl_all

if logfile:
	f = open(logfile,"a")
	s1 = 'Step5: \n'
	f.write(s1)

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Local variables:
sif = InputFeature.split("\\")
iName = sif[len(sif)-1]

landform_edits_layer = "landform_edits_layer"
ein = arcpy.env.workspace + os.sep + iName + "_EIN"
ein_layer = "ein_layer"
ein_d = arcpy.env.workspace + os.sep + iName + "_EIN_D"
ein_dex = arcpy.env.workspace + os.sep + iName + "_EIN_Dex"
ein_dex_layer = "ein_dex_layer"
landforms = arcpy.env.workspace + os.sep + "final_landforms"

arcpy.AddMessage('Output Feature: ' + ein)
arcpy.AddMessage('Output Landforms: ' + landforms)

###	ELIMINATE NOISE	##########################################

# Process: Eliminate noise
arcpy.AddMessage(' ')
arcpy.AddMessage('Eliminate noise...')
inum = arcpy.NOISEelim(InputFeature,is_iter)

if str(is_iter) == 'true':
	if str(inum) == '5':
		s2 = '	Max number of iterations (5) reached: Possible residual noise'
	else:
		s2 = '	All noise removed'
else:
	s2 = '	No Noise elimination iterations performed: Possible residual noise'

arcpy.AddMessage(s2)
arcpy.AddMessage(' ')
if logfile:
	f.write(s2 + '\n')

###	RELABEL	##########################################

arcpy.AddMessage('ReLabel...')

# Process: Add Field
arcpy.AddMessage('	Add Field...')
arcpy.AddField_management(ein,"LANDFORM","TEXT","","","100","","NULLABLE","NON_REQUIRED","")

# Process: Calculate Field
arcpy.AddMessage('	Calculate Field...')
arcpy.CalculateField_management(ein,"LANDFORM","!PrelimLand!","PYTHON_9.3","")

# Process: Make Feature Layer
arcpy.AddMessage('	Make Feature Layer...')
arcpy.MakeFeatureLayer_management(ein,ein_layer)

steps = [1,2,3]
for step in steps:
	if step==1:
		where_clause = "LANDFORM = 'Peaks REVIEW'"
		expr = "'Peaks'"
	elif step==2:
		where_clause = "LANDFORM = 'Reefs/Banks REVIEW'"
		expr = "'Reefs/Banks'"
	elif step==3:
		where_clause = "LANDFORM = 'Depressions and channels Rugose REVIEW'"
		expr = "'Reefs/Banks'"

	arcpy.AddMessage('	Step: ' + str(step))

	# Process: Select Layer by Attribute
	arcpy.SelectLayerByAttribute_management(ein_layer,"NEW_SELECTION",where_clause)

	# Process: Calculate Field
	arcpy.CalculateField_management(ein_layer,"LANDFORM",expr,"PYTHON_9.3","")

	# Process: Clear Selection
	arcpy.SelectLayerByAttribute_management(ein_layer,"CLEAR_SELECTION","")

###	ELIMINATE SMALL POLYGONS	##########################################

arcpy.AddMessage('Eliminate Small Polygons...')

# Process: Dissolve
arcpy.AddMessage('	Dissolve...')
arcpy.Dissolve_management(ein,ein_d, "LANDFORM","","MULTI_PART","DISSOLVE_LINES") 

# Process: Multi to Single
arcpy.AddMessage('	Multi to Single...')
arcpy.MultipartToSinglepart_management(ein_d,ein_dex)

###	ELIMINATE SMALL POLYGONS (Optional)	##########################################

if PolyThreshold:
	where_clause = "Shape_Area <= " + PolyThreshold
	s3 = '	Eliminating small polygons <= ' + PolyThreshold + 'm2'

	# Process: Make Feature Layer
	arcpy.MakeFeatureLayer_management(ein_dex,ein_dex_layer)

	# Process: Select Layer by Attribute
	arcpy.SelectLayerByAttribute_management(ein_dex_layer,"NEW_SELECTION",where_clause)

	# Process: Eliminate small polygons
	arcpy.Eliminate_management(ein_dex_layer, landforms,"LENGTH")

else:
	s3 = '	Not eliminating small polygons!'
	
	# Process: Copy Features
	arcpy.CopyFeatures_management(ein_dex,landforms)

arcpy.AddMessage(s3)
arcpy.AddMessage(' ')

if logfile:
	f.write(s3 + '\n')
	f.close()

# Remove *EIN
arcpy.Delete_management(ein)
arcpy.Delete_management(ein_d)
arcpy.Delete_management(ein_dex)

# Add to map
nl = arcpy.mapping.Layer(landforms)
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Landforms.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Landforms.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)
	
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()

