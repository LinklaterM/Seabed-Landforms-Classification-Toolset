# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LAND-bound-poly.py
# Created on: 2020-06-15 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: LANDboundpoly <surf_elem>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)

# Local variables:
surf_elem_D = arcpy.env.workspace + os.sep + "surf_elem_D"
sum_surfel = arcpy.env.workspace + os.sep + "sum_surfel"
study_area_Er_all_rug_classes_b = arcpy.env.workspace + os.sep + "study_area_Er_all_rug_classes_b"
study_area_Er_rug_outcrops_b = arcpy.env.workspace + os.sep + "study_area_Er_rug_outcrops_b"
study_area_Er_all_rug_classes = arcpy.env.workspace + os.sep + "study_area_Er_all_rug_classes"
study_area_Er_rug_outcrops = arcpy.env.workspace + os.sep + "study_area_Er_rug_outcrops"

study_area = arcpy.env.scratchWorkspace + os.sep + "study_area"
study_area_buff = arcpy.env.scratchWorkspace + os.sep + "study_area_buff1km"
rug_outcrops = arcpy.env.scratchWorkspace + os.sep + "rug_outcrops"
study_area_buff_Er = arcpy.env.scratchWorkspace + os.sep + "study_area_buff1km_Er"
study_area_buff_Er_all_rug = arcpy.env.scratchWorkspace + os.sep + "study_area_buff1km_Er_all_rug"
all_rug_classes = arcpy.env.scratchWorkspace + os.sep + "all_rug_classes"

sum_surfel_layer = "sum_surfel_layer"

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

###	STEP 1	##########################################
arcpy.AddMessage(' ')
arcpy.AddMessage('STEP 1...')
# Process: Dissolve
arcpy.AddMessage('Dissolving...')
arcpy.Dissolve_management(InputFeatureClass,surf_elem_D,"SUM_SE","","MULTI_PART","DISSOLVE_LINES")

# Process: Multipart to singlepart
arcpy.AddMessage('Multi to Single...')
arcpy.MultipartToSinglepart_management(surf_elem_D, sum_surfel)

###	STEP 2	##########################################
arcpy.AddMessage(' ')
arcpy.AddMessage('STEP 2...')
# Process: Dissolve (study area)
arcpy.AddMessage('Dissolving (study area)...')
arcpy.Dissolve_management(InputFeatureClass,study_area,"","","MULTI_PART","DISSOLVE_LINES")

# Process: Buffer
arcpy.AddMessage('Buffering (study area)...')
arcpy.Buffer_analysis(study_area,study_area_buff,"10000 Meters","FULL","ROUND","NONE","","PLANAR")

# Process: Make Feature Layer
arcpy.AddMessage('Make Feature Layer...')
arcpy.MakeFeatureLayer_management(sum_surfel,sum_surfel_layer)

###	STEP 3 + 4	##########################################
steps = [3,4]
for step in steps:
	arcpy.AddMessage(' ')
	arcpy.AddMessage('STEP ' + str(step) + '...')

	if step==3:
		where_clause="SUM_SE = 'Rugose Outcrop Peak' OR SUM_SE = 'Rugose Outcrop' OR SUM_SE = 'Slope'"
		rug = rug_outcrops
		sa_buff = study_area_buff_Er
		sa_Er = study_area_Er_rug_outcrops_b
	elif step==4:

		where_clause="SUM_SE = 'Rugose Outcrop Peak' OR SUM_SE = 'Rugose Outcrop' OR SUM_SE = 'Rugose Low' OR SUM_SE = 'Slope'"
		rug = all_rug_classes
		sa_buff = study_area_buff_Er_all_rug
		sa_Er = study_area_Er_all_rug_classes_b

	# Process: Select Layer by Attributes	
	arcpy.AddMessage('Select Layer by attributes...')
	arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"NEW_SELECTION",where_clause)

	# Process: Copy Features
	arcpy.AddMessage('Copy Features...')
	arcpy.CopyFeatures_management(sum_surfel_layer,rug)

	# Process: Erase
	arcpy.AddMessage('Erasing...')
	arcpy.Erase_analysis(study_area_buff,rug,sa_buff,"")

	# Process: Multipart to singlepart
	arcpy.AddMessage('Multi to Single...')
	arcpy.MultipartToSinglepart_management(sa_buff,sa_Er)


###	STEP 5	##########################################
arcpy.AddMessage(' ')
arcpy.AddMessage('STEP 5...')

# Get rid of largest polygon
arcpy.AddMessage('Remove Buffer...')
arcpy.LANDboundbuffer(study_area_Er_all_rug_classes_b,study_area_Er_all_rug_classes)
arcpy.LANDboundbuffer(study_area_Er_rug_outcrops_b,study_area_Er_rug_outcrops)

sys.exit()

