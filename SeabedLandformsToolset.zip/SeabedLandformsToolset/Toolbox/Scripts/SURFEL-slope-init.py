# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# SURFEL-slope-init.py
# Created on: 2019-11-13 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: SURFELslopeinit <DEM>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
DEM = arcpy.GetParameterAsText(0)

arcpy.AddMessage('   DEM: ' + DEM)

# Local variables:
slope = arcpy.env.scratchWorkspace + os.sep + "slope"

# Process: Slope (spatial analyst)
#Slope_sa (in_raster, {output_measurement}, {z_factor}, out_raster) 
arcpy.AddMessage('Calculate Slope...')
outSlope=Slope(DEM,"DEGREE",1)
outSlope.save(slope)

sys.exit()
