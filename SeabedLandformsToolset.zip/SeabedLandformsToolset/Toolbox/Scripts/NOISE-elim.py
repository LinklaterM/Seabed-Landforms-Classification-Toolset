# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# NOISE-elim.py
# Created on: 2021-01-25 13:37:37.00000
# 
# Usage: NOISEelim <InputFeature, Iterate>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])
arcpy.AddMessage('   Base_Dir: ' + Base_Dir)
arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Script arguments
InputFeature = arcpy.GetParameterAsText(0)
is_iter = arcpy.GetParameterAsText(1)

sif = InputFeature.split("\\")
iName = sif[len(sif)-1]
ins = iName.split(".")
iName = ins[0]
scom = iName.split("_")
sed_comp = scom[0]

arcpy.AddMessage('Input Feature Layer: ' + InputFeature)
#arcpy.AddMessage('Input Feature: ' + iName)
arcpy.AddMessage('Sediment Compartment: ' + sed_comp)
#arcpy.AddMessage('Iterate: ' + is_iter)

# Local variables:
landform_edits_layer = "landform_edits_layer"
ein = arcpy.env.workspace + os.sep + iName + "_EIN"
ein_temp = arcpy.env.scratchWorkspace + os.sep + iName + "_temp"
ein_layer = "ein_layer"
#ein_d = arcpy.env.workspace + os.sep + iName + "_EIN_D"
#ein_dex = arcpy.env.workspace + os.sep + iName + "_EIN_Dex"
#ein_dex_layer = "ein_dex_layer"
#landforms = arcpy.env.workspace + os.sep + iName + "_Landforms"

arcpy.AddMessage('Output Feature: ' + ein)

#sys.exit()

###	ELIMINATE NOISE	##########################################

# Process: Make Feature Layer
##MakeFeatureLayer_management (in_features, out_layer, {where_clause}, {workspace}, {field_info}) 
arcpy.AddMessage('Make Feature Layer...')
arcpy.MakeFeatureLayer_management(InputFeature,landform_edits_layer)

# Process: Select Layer by Attribute
##SelectLayerByAttribute_management (in_layer_or_view, {selection_type}, {where_clause}) 
arcpy.AddMessage('Select Layer by attributes...')
where_clause = "PrelimLand = '[Noise]'"
arcpy.SelectLayerByAttribute_management(landform_edits_layer,"NEW_SELECTION",where_clause)

# Process: Eliminate noise polygons
##Eliminate_management (in_features, out_feature_class, {selection}, {ex_where_clause}, {ex_features}) 
arcpy.AddMessage('Eliminate noise polygons...')
arcpy.Eliminate_management(landform_edits_layer, ein_temp,"LENGTH")

###	ITERATE TO REMOVE ALL NOISE	########################################

# Process: Make Feature Layer
##MakeFeatureLayer_management (in_features, out_layer, {where_clause}, {workspace}, {field_info}) 
arcpy.AddMessage('Make Feature Layer...')
arcpy.MakeFeatureLayer_management(ein_temp,ein_layer)

# Process: Select Layer by Attribute
##SelectLayerByAttribute_management (in_layer_or_view, {selection_type}, {where_clause}) 
arcpy.AddMessage('Select Layer by attributes...')
where_clause = "PrelimLand = '[Noise]'"
arcpy.SelectLayerByAttribute_management(ein_layer,"NEW_SELECTION",where_clause)

# Process: Get Noise Count
n_count = arcpy.GetCount_management(ein_layer)
arcpy.AddMessage('Noise Count: ' + n_count[0])

inum = 1

if str(is_iter) == 'true':
	while int(n_count[0]) > 0:
		arcpy.AddMessage('Iteration: ' + str(inum))

		# Process: Delete layer
		##Delete_management (in_data, {data_type}) 
		arcpy.Delete_management(ein_layer) 

		# Process: Make Feature Layer
		##MakeFeatureLayer_management (in_features, out_layer, {where_clause}, {workspace}, {field_info}) 
		#arcpy.AddMessage('Make Feature Layer...')
		arcpy.MakeFeatureLayer_management(ein_temp,ein_layer)

		# Process: Select Layer by Attribute
		##SelectLayerByAttribute_management (in_layer_or_view, {selection_type}, {where_clause}) 
		#arcpy.AddMessage('Select Layer by attributes...')
		where_clause = "PrelimLand = '[Noise]'"
		arcpy.SelectLayerByAttribute_management(ein_layer,"NEW_SELECTION",where_clause)

		ein_temp = ein_temp + str(inum)

		# Process: Eliminate noise polygons
		##Eliminate_management (in_features, out_feature_class, {selection}, {ex_where_clause}, {ex_features}) 
		arcpy.AddMessage('	Eliminate noise polygons...')
		arcpy.Eliminate_management(ein_layer, ein_temp,"LENGTH")

		# Process: Delete layer
		##Delete_management (in_data, {data_type}) 
		arcpy.Delete_management(ein_layer) 

		# Process: Make Feature Layer
		##MakeFeatureLayer_management (in_features, out_layer, {where_clause}, {workspace}, {field_info}) 
		#arcpy.AddMessage('Make Feature Layer...')
		arcpy.MakeFeatureLayer_management(ein_temp,ein_layer)

		# Process: Select Layer by Attribute
		##SelectLayerByAttribute_management (in_layer_or_view, {selection_type}, {where_clause}) 
		#arcpy.AddMessage('Select Layer by attributes...')
		where_clause = "PrelimLand = '[Noise]'"
		arcpy.SelectLayerByAttribute_management(ein_layer,"NEW_SELECTION",where_clause)

		n_count = arcpy.GetCount_management(ein_layer)
		arcpy.AddMessage('	Noise Count: ' + n_count[0])

		inum = inum + 1
		
		if inum == 5:
			arcpy.AddMessage('	Stopped Iteration...')
			break

if inum < 5:
	arcpy.AddMessage('Noise Eliminated')

arcpy.SetParameterAsText(2,inum)

# Process: Copy
##Copy_management (in_data, out_data, {data_type}) 
arcpy.AddMessage('Copy to final...')
arcpy.Copy_management(ein_temp,ein) 

sys.exit()
