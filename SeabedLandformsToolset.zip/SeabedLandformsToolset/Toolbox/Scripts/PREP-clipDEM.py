# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# PREP-clipDEM.py
# Created on: 2019-11-13 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: PREPclipDEM <DEM> <DEMout> <UpperValue> <LowerValue>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
DEM = arcpy.GetParameterAsText(0)
RegLabel = arcpy.GetParameterAsText(1)
UpperValue = arcpy.GetParameterAsText(2)
LowerValue = arcpy.GetParameterAsText(3)

arcpy.AddMessage('   DEM (in): ' + DEM)
isplit = DEM.split("\\")
DEMfile = isplit[len(isplit)-1]

# Local variables:
if RegLabel:
	output_dir = Base_Dir + os.sep + "DEM_" + RegLabel + ".gdb"

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Create output gdb if required
if RegLabel:
	if os.path.exists(output_dir) == False:
		##CreateFileGDB_management (out_folder_path, out_name, {out_version}) 
		arcpy.CreateFileGDB_management(Base_Dir,"DEM_" + RegLabel + ".gdb")
		arcpy.AddMessage('   create out gdb: ' + output_dir)
	
# Process Set Null (depths > cutoff value [nominally 0])
##SetNull_sa(in_conditional_raster, in_false_raster_or_constant, {where_clause}, out_raster) 
arcpy.AddMessage('Set Null...')
if LowerValue:
	whereClause = "VALUE > " + UpperValue + " OR VALUE < " + LowerValue
	maxD = abs(int(LowerValue))
else:
	whereClause = "VALUE > " + UpperValue
	maxRes = arcpy.GetRasterProperties_management(DEM,"MINIMUM")
	maxD = int(round(abs(float(maxRes.getOutput(0)))))

minD = abs(int(UpperValue))
arcpy.AddMessage('   Upper cutoff value (m): ' + str(minD))
arcpy.AddMessage('   Lower cutoff value (m): ' + str(maxD))

if RegLabel:
	DEMout = output_dir + os.sep + DEMfile + "_" + str(minD) + "m_" + str(maxD) + "m"
else:
	DEMout = DEM + "_" + str(minD) + "m_" + str(maxD) + "m"
	
arcpy.AddMessage('	DEMout: ' + DEMout)

outSetNull = SetNull(DEM,DEM,whereClause)
outSetNull.save(DEMout)

# Add to map
nl = arcpy.mapping.Layer(DEMout)
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "DEM.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "DEM.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)

arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()
