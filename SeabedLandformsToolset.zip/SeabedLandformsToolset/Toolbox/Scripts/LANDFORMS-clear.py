# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-clear.py
# Created on: 2020-02-21 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: LANDFORMSclear 
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Script arguments
lyrlist = arcpy.mapping.ListLayers(df)
for l in lyrlist:
	if l.supports("workspacePath"):
		if l.workspacePath == arcpy.env.workspace:
			arcpy.mapping.RemoveLayer(df,l)
			arcpy.AddMessage(l.workspacePath)

arcpy.AddMessage('Cleaning Scratch/Working gdbs')

# Process: clear working.gdb
arcpy.AddMessage('Deleting Working ...')
fc_list = arcpy.ListFeatureClasses()
for fc in fc_list:
	arcpy.Delete_management(fc)
	arcpy.AddMessage('	' + fc)

ds_list = arcpy.ListDatasets()
for ds in ds_list:
	arcpy.Delete_management(ds)
	arcpy.AddMessage('	' + ds)

# Process: clear scratch.gdb
arcpy.env.workspace = Base_Dir + os.sep + "Scratch.gdb"
arcpy.AddMessage('Deleting Scratch ...')
fc_list = arcpy.ListFeatureClasses()
for fc in fc_list:
	arcpy.Delete_management(fc)
#	arcpy.AddMessage(fc)

ds_list = arcpy.ListDatasets()
for ds in ds_list:
	arcpy.Delete_management(ds)
#	arcpy.AddMessage(ds)

sys.exit()
