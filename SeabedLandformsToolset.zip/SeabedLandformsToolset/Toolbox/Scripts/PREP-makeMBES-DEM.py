# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# PREP-makeMBES-DEM.py
# Created on: 2019-11-13 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: PREPmakeMBESDEM <xyz> <point_spacing> <RegLabel> <coordinate system> <negate>
# Description: 
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("3D")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
xyz_in = arcpy.GetParameterAsText(0)
InputNum = arcpy.GetParameterAsText(1)
RegLabel = arcpy.GetParameterAsText(2)
sr = arcpy.GetParameterAsText(3)
is_neg = arcpy.GetParameterAsText(4)

isplit = xyz_in.split("\\")
xyz = isplit[len(isplit)-1]
nsplit = xyz.split("_")
sp = int(InputNum)

# Local variables:
output_dir = Base_Dir + os.sep + "DEM_" + RegLabel + ".gdb"
xyz_poly = arcpy.env.scratchWorkspace + os.sep + "_".join(nsplit[0:len(nsplit)-1]) + "_poly"
dem_el = arcpy.env.scratchWorkspace + os.sep + "_".join(nsplit[0:len(nsplit)-1]) + "_e"
dem = output_dir + os.sep + "_".join(nsplit[0:len(nsplit)-1])

arcpy.AddMessage('   xyz: ' + xyz)
arcpy.AddMessage('   DEM: ' + dem)

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Create output gdb if required
if os.path.exists(output_dir) == False:
	arcpy.CreateFileGDB_management(Base_Dir,"DEM_" + RegLabel + ".gdb")
	arcpy.AddMessage('   create out gdb: ' + output_dir)

# Process: ASCII to Feature Class
arcpy.AddMessage('Convert xyz to poly...')
arcpy.ASCII3DToFeatureClass_3d(xyz_in,"XYZ",xyz_poly,"MULTIPOINT","",sr,sp)

# Process: Point to Raster
arcpy.AddMessage('Convert poly to raster...')
arcpy.PointToRaster_conversion(xyz_poly,"Shape.Z",dem_el,"MEAN","",5)

if str(is_neg) == 'true':
	# Process: Negate
	arcpy.AddMessage('Convert to depths...')
	outNegate = Negate(dem_el)
	outNegate.save(dem)
else:
	arcpy.AddMessage('Copy to gdb...')
	arcpy.Copy_management(dem_el,dem)
	
# Add to map
nl = arcpy.mapping.Layer(dem)
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "DEM.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "DEM.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)

arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()

