# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-terrain.py
# Created on: 2019-11-15 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: LANDFORMSterrain <DEM><WinSize_BBPI><WinSize_FBPI>
# Description: LANDFORMS step 1 terrain variables
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os, datetime
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
DEM = arcpy.GetParameterAsText(0)
WinSize_BBPI = arcpy.GetParameterAsText(1)
if WinSize_BBPI == '#' or not WinSize_BBPI:
    WinSize_BBPI = "150" # provide a default value if unspecified
WinSize_FBPI = arcpy.GetParameterAsText(2)
if WinSize_FBPI == '#' or not WinSize_FBPI:
	WinSize_FBPI = "27" # provide a default value if unspecified

s1 = '	DEM:' + DEM
s2 = '	Broad BPI Window Size: ' + WinSize_BBPI
s3 = '	Fine BPI Window Size: ' + WinSize_FBPI

arcpy.AddMessage(s1)
arcpy.AddMessage(s2)
arcpy.AddMessage(s3)

# Delete existing layers from map
lyrlist = arcpy.mapping.ListLayers(df)
for l in lyrlist:
	if l.supports("workspacePath"):
		if l.workspacePath == arcpy.env.scratchWorkspace:
			arcpy.mapping.RemoveLayer(df,l)
						
# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Process: SURFEL Slope
arcpy.AddMessage('Calculate slope ... ')
arcpy.SURFELslopeinit(DEM)

# Process: SURFEL Ruggedness
arcpy.AddMessage('Calculate ruggedness (VRM) ... ')
arcpy.SURFELruggednessinit(DEM)

# Process: SURFEL Broad TPI
arcpy.AddMessage('Calculate Broad TPI ... ')
arcpy.SURFELbroadbpiinit(DEM, WinSize_BBPI)

# Process: SURFEL Fine TPI
arcpy.AddMessage('Calculate Fine TPI ... ')
arcpy.SURFELfinebpiinit(DEM, WinSize_FBPI)

# Add to map (slope)
nl = arcpy.mapping.Layer(arcpy.env.scratchWorkspace + os.sep + "slope")
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Slope.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Slope.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)
	
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

# Add to map (vrm)
nl = arcpy.mapping.Layer(arcpy.env.scratchWorkspace + os.sep + "vrm")
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Ruggedness.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Ruggedness.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)
	
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

# Add to map (BBPI)
nl = arcpy.mapping.Layer(arcpy.env.scratchWorkspace + os.sep + "broadbpi")
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Broad_BPI.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Broad_BPI.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)
	
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

# Add to map (FBPI)
nl = arcpy.mapping.Layer(arcpy.env.scratchWorkspace + os.sep + "finebpi")
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Fine_BPI.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "Fine_BPI.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)
	
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()
