# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LAND-relabel.py
# Created on: 2020-06-17 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: LANDrelabel <reclass_union>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)

# Local variables:
sum_surfel_layer = "sum_surfel_layer"
study_area_Er_rug_outcrops = arcpy.env.workspace + os.sep + "study_area_Er_rug_outcrops"

# Process: Delete Fields
arcpy.DeleteField_management(InputFeatureClass,"LAND_1") 

###	STEP 1	##########################################
arcpy.AddMessage(' ')
arcpy.AddMessage('STEP 1...')

# Process: Add Field
arcpy.AddMessage('Add Field...')
arcpy.AddField_management(InputFeatureClass,"LAND_1","TEXT","","","100","","NULLABLE","NON_REQUIRED","")

# Process: Calculate Field
arcpy.AddMessage('Calculate Field...')
arcpy.CalculateField_management(InputFeatureClass,"LAND_1","!SUM_SE!","PYTHON_9.3","")

# Process: Make Feature Layer
arcpy.AddMessage('Make Feature Layer...')
arcpy.MakeFeatureLayer_management(InputFeatureClass,sum_surfel_layer)

steps = [2,3,4,5,6,7,8,9,10,11,12,13,14]
for step in steps:
	arcpy.AddMessage(' ')
	arcpy.AddMessage('STEP ' + str(step) + '...')

	if step==2:
		where_clause = "LAND_1 = 'Smooth Flat' AND WithinRug = 'Within rugose outcrops'"
		field = "LAND_1"
		expr = "'Reefs/Banks REVIEW'"
	elif step==3:
		where_clause = "LAND_1 = 'Smooth Flat' AND WithinRug = 'Within rugose outcrops'"
		field = "LAND_1"
		expr = "'Reefs/Banks REVIEW'"
	elif step==4:
		where_clause = "LAND_1 = 'Smooth Outcrop' AND WithinRug = 'Within rugose outcrops'"
		field = "LAND_1"
		expr = "'Peaks REVIEW'"
	elif step==5:
		where_clause = "LAND_1 = 'Rugose Low' AND WithinRug = 'Within rugose outcrops'"
		field = "LAND_1"
		expr = "'Depressions and channels Rugose'"
	elif step==6:
		where_clause = "LAND_1 = 'Smooth Low' AND WithinRug = 'Within rugose outcrops'"
		field = "LAND_1"
		expr = "'Depressions and channels Smooth'"
	elif step==7:
		where_clause = "LAND_1 = 'Rugose Low'"
		field = "LAND_1"
		expr = "'Depressions and channels Rugose REVIEW'"
	elif step==8:
		where_clause="LAND_1 = 'Smooth Outcrop' AND WithinAllR = 'Within all rugose classes'"
		field = "LAND_1"
		expr = "'Peaks REVIEW'"
	elif step==9:
		where_clause = "LAND_1 = 'Smooth Flat' AND WithinAllR = 'Within all rugose classes'"
		field = "LAND_1"
		expr = "'Reefs/Banks REVIEW'"
	elif step==10:
		where_clause = "LAND_1 = 'Smooth Low' AND WithinAllR = 'Within all rugose classes'"
		field = "LAND_1"
		expr = "'Depressions and channels Smooth'"
	elif step==11:
		where_clause = "LAND_1 = 'Rugose Outcrop Peak'"
		field = "LAND_1"
		expr = "'Peaks'"
	elif step==12:
		where_clause = "LAND_1 = 'Rugose Outcrop'"
		field = "LAND_1"
		expr = "'Reefs/Banks'"
	elif step==13:
		where_clause = "LAND_1 = 'Smooth Flat' OR LAND_1 = 'Smooth Low' OR LAND_1 = 'Smooth Outcrop'"
		field = "LAND_1"
		expr = "'Plains'"
	elif step==14:
		where_clause = "LAND_1 = 'Slope'"
		field = "LAND_1"
		expr = "'Scarps'"
	else:
		where_clause="None"
	
	# Process: Select Layer by Attribute
	arcpy.AddMessage('Select Layer by attributes...')
	arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"NEW_SELECTION",where_clause)

	if step==2:
		# Process: Select Layer by Location
		arcpy.AddMessage('Select Layer...')	
		arcpy.SelectLayerByLocation_management(sum_surfel_layer,"ARE_IDENTICAL_TO",study_area_Er_rug_outcrops,"","SUBSET_SELECTION","NOT_INVERT")

	# Process: Calculate Field
	arcpy.AddMessage('Calculate Field...')
	arcpy.CalculateField_management(sum_surfel_layer,field,expr,"PYTHON_9.3","")

	# Process: Clear Selection
	arcpy.AddMessage('Clear Selection...')
	arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"CLEAR_SELECTION","")

sys.exit()
