# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-surfel.py
# Created on: 2019-11-15 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: LANDFORMSsurfel <DEM><Slope_threshold><Rugged_threshold><BBPI_threshold><FBPI_threshold><WinSize_BBPI><WinSize_FBPI>
# Description: LANDFORMS step 2 surface elements
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os, datetime
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
DEM = arcpy.GetParameterAsText(0)
#Depth_threshold = arcpy.GetParameterAsText(1)
#if Depth_threshold == '#' or not Depth_threshold:
#    Depth_threshold = "-7;0" # provide a default value if unspecified
Slope_threshold = arcpy.GetParameterAsText(1)
if Slope_threshold == '#' or not Slope_threshold:
    Slope_threshold = "10" # provide a default value if unspecified
Rugged_threshold = arcpy.GetParameterAsText(2)
if Rugged_threshold == '#' or not Rugged_threshold:
    Rugged_threshold = "0.00005" # provide a default value if unspecified
BBPI_threshold = arcpy.GetParameterAsText(3)
if BBPI_threshold == '#' or not BBPI_threshold:
    BBPI_threshold = "-100;100" # provide a default value if unspecified
FBPI_threshold = arcpy.GetParameterAsText(4)
if FBPI_threshold == '#' or not FBPI_threshold:
    FBPI_threshold = "-100;100" # provide a default value if unspecified
WinSize_BBPI = arcpy.GetParameterAsText(5)
if WinSize_BBPI == '#' or not WinSize_BBPI:
    WinSize_BBPI = "150" # provide a default value if unspecified
WinSize_FBPI = arcpy.GetParameterAsText(6)
if WinSize_FBPI == '#' or not WinSize_FBPI:
	WinSize_FBPI = "27" # provide a default value if unspecified

#dth = Depth_threshold.split(";")
bth = BBPI_threshold.split(";")
fth = FBPI_threshold.split(";")

# Write to settings log file
d = datetime.datetime.now()
f = open('CurrentSession_Settings_LANDFORMS_' + d.strftime('%Y%m%d%H%M') + '.txt',"w")

s1 = 'Step1:'
s2 = '	DEM:' + DEM
#s3 = '	Depth Threshold: [' + dth[0] + ',' + dth[1] + ']'
s4 = '	Slope Threshold: ' + Slope_threshold
s5 = '	Ruggedness Threshold: ' + Rugged_threshold
s6 = '	Broad BPI Threshold: [' + bth[0] + ',' + bth[1] + ']'
s7 = '	Fine BPI Threshold: [' + fth[0] + ',' + fth[1] + ']'
s8 = '	Broad BPI Window Size: ' + WinSize_BBPI
s9 = '	Fine BPI Window Size: ' + WinSize_FBPI
#s = s1 + '\n' + s2 + '\n' + s3 + '\n' + s4 + '\n' + s5 + '\n' + s6 + '\n' \
#	+ s7 + '\n' + s8 + '\n' + s9 + '\n'
s = s1 + '\n' + s2 + '\n' + s4 + '\n' + s5 + '\n' + s6 + '\n' \
	+ s7 + '\n' + s8 + '\n' + s9 + '\n'

arcpy.AddMessage(s2)
#arcpy.AddMessage(s3)
arcpy.AddMessage(s4)
arcpy.AddMessage(s5)
arcpy.AddMessage(s6)
arcpy.AddMessage(s7)
arcpy.AddMessage(s8)
arcpy.AddMessage(s9)

f.write(s)
f.close()

# Local variables:
union_poly = arcpy.env.workspace + os.sep + "surf_elem_union"
union_poly_d = arcpy.env.workspace + os.sep + "surf_elem"

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Process: SURFEL depth
#arcpy.AddMessage('Reclassify depth ... ')
#arcpy.SURFELdepth(DEM,Depth_threshold)

# Process: SURFEL Slope
arcpy.AddMessage('Calculate slope ... ')
arcpy.SURFELslope(DEM, Slope_threshold)

# Process: SURFEL Ruggedness
arcpy.AddMessage('Calculate ruggedness (VRM) ... ')
arcpy.SURFELruggedness(DEM, Rugged_threshold)

# Process: SURFEL Broad TPI
arcpy.AddMessage('Calculate Broad TPI ... ')
arcpy.SURFELbroadbpi(DEM, WinSize_BBPI, BBPI_threshold)

# Process: SURFEL Fine TPI
arcpy.AddMessage('Calculate Fine TPI ... ')
arcpy.SURFELfinebpi(DEM, WinSize_FBPI, FBPI_threshold)

# Process: SURFEL union surface elements
arcpy.AddMessage('Create Surface Elements union ... ')
arcpy.SURFELunionsurfel()

fc = union_poly
if arcpy.Exists(fc):
	# Process: SURFEL calculate surface elements
	arcpy.AddMessage('Calculate Surface Elements ... ')
	arcpy.SURFELsurfel(union_poly)
	
	# Process: SURFEL simplify surface elements
	arcpy.AddMessage('Simplify Surface Elements ... ')
	arcpy.SURFELsumse(union_poly)
	
	# Process: Dissolve
	arcpy.AddMessage('Dissolving...')
	arcpy.Dissolve_management(union_poly,union_poly_d,["SURF_EL", "SUM_SE"])
else:
	arcpy.AddMessage('Need to calculate Surface Elements manually!')

# Add to map
nl = arcpy.mapping.Layer(union_poly_d)
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "SummarisedSurfaceElements_surf_elem.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "SummarisedSurfaceElements_surf_elem.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)
	
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()

