# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# SURFEL-transfer.py
# Created on: 2020-03-12 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: SURFELtransfer <RegLabel>
# Description: LANDFORMS step 5 transfer surfel files
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os, operator
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Define Spatial Reference
sr = arcpy.Describe(arcpy.env.workspace + os.sep + "surf_elem").SpatialReference

# Script arguments
RegLabel = arcpy.GetParameterAsText(0)

arcpy.AddMessage('   Region Label: ' + RegLabel)
output_dir = Base_Dir + os.sep + "SURFEL_" + RegLabel + ".gdb"
	
# Create output database if does not exist
if os.path.exists(output_dir) == False:
	arcpy.CreateFileGDB_management(Base_Dir,"SURFEL_" + RegLabel + ".gdb")
	arcpy.AddMessage('   create out: ' + output_dir)

	arcpy.CreateFeatureDataset_management(output_dir,"reclass",sr)
	
arcpy.AddMessage('Transfer results for ' + RegLabel)

# Clear layers from map
u_list = ['surf_elem', 'drainage', 'depth_reclass']
lyrlist = arcpy.mapping.ListLayers(df)
for l in lyrlist:
	for u in u_list:
		if operator.contains(l.name.lower(),u):
			arcpy.mapping.RemoveLayer(df,l)

# From Scratch
transfer_list=['slope', 'vrm', 'broadbpi', 'finebpi']
for tl in transfer_list:
	if arcpy.Exists(arcpy.env.scratchWorkspace + os.sep + tl):
		arcpy.AddMessage('	' + tl + ' to ' + RegLabel + '_' + tl)
		arcpy.Copy_management(arcpy.env.scratchWorkspace + os.sep + tl, \
			output_dir + os.sep + RegLabel + "_" + tl)
	else:
		arcpy.AddMessage('	No ' + tl)
		
# From Working (main)
#u_list = ['surf_elem', 'drainage', 'depth_reclass']
u_list = ['surf_elem', 'depth_reclass']
for u in u_list:
	if arcpy.Exists(arcpy.env.workspace + os.sep + u):
		arcpy.AddMessage('	' + u + ' to ' + RegLabel + '_' + u)
		arcpy.Copy_management(arcpy.env.workspace + os.sep + u, \
				output_dir + os.sep + RegLabel + "_" + u)
	else:
		arcpy.AddMessage('	No ' + u)

# From Working (drainage raster)
u = 'drainage'
if arcpy.Exists(arcpy.env.workspace + os.sep + u):
	arcpy.AddMessage('	' + u + ' to ' + RegLabel + '_' + u)
	arcpy.CopyRaster_management(arcpy.env.workspace + os.sep + u, \
			output_dir + os.sep + RegLabel + "_" + u)
else:
	arcpy.AddMessage('	No ' + u)


# From Working (reclass)
u_list = ['surf_elem_union', 'slope_reclass', 'vrm_reclass',\
		'broadbpi_reclass', 'finebpi_reclass']
for u in u_list:
	if arcpy.Exists(arcpy.env.workspace + os.sep + u):
		arcpy.AddMessage('	' + u + ' to ' + RegLabel + '_' + u)
		arcpy.FeatureClassToFeatureClass_conversion(arcpy.env.workspace + os.sep + u, \
				output_dir + os.sep + "reclass", \
				RegLabel + "_" + u)
	else:
		arcpy.AddMessage('	No ' + u)

# Tidyup
arcpy.LANDFORMSclear()
arcpy.AddMessage('Cleaning Scratch/Working gdbs')

sys.exit()
