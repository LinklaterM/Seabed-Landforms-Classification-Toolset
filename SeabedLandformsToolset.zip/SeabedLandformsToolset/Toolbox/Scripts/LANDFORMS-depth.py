# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-depth.py
# Created on: 2019-11-13 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: LANDFORMSdepth <DEM><Interval>
# Description: LANDFORMS step 3 OPTIONAL depth reclassification
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
DEM = arcpy.GetParameterAsText(0)
Interval = arcpy.GetParameterAsText(1)
    
arcpy.AddMessage('   DEM: ' + DEM)
arcpy.AddMessage('   Interval: ' + Interval)

# Local variables:
depth_reclass = arcpy.env.scratchWorkspace + os.sep + "depth_reclass_raster"
depth_reclass_poly = arcpy.env.workspace + os.sep + "depth_reclass_poly"
depth_reclass_poly_d = arcpy.env.workspace + os.sep + "depth_reclass"
depth_reclass_layer = "depth_reclass_layer"

maxRes = arcpy.GetRasterProperties_management(DEM,"MINIMUM")
maxDr = int(math.floor(float(maxRes.getOutput(0))/10)*10)

minRes = arcpy.GetRasterProperties_management(DEM,"MAXIMUM")
minDr = int(math.ceil(float(minRes.getOutput(0))/10)*10)

arcpy.AddMessage('Min depth: ' + minRes.getOutput(0))
arcpy.AddMessage('Max depth: ' + maxRes.getOutput(0))

s = maxDr
dl = []
while s <= minDr:
	dl.append(s)
	s = s + int(Interval)

i = 0
dr = []
drs = []
for d in dl:
	dlr = []
	if i < len(dl)-1:
		dlr.append(d)	
		dlr.append(dl[i+1])
		dlr.append(i+1)
	
		drs.append(str(d) + ' - ' + str(dl[i+1]))
	else:
		dlr.append(d)
		dlr.append(300)
		dlr.append("NODATA")
		
	dr.append(dlr)
	i = i + 1
	
arcpy.AddMessage(dr)

# Process: Reclassify (spatial analyst)
arcpy.AddMessage('Reclassify...')
remap = RemapRange(dr)
outReclass = Reclassify(DEM,"VALUE",remap)
outReclass.save(depth_reclass)

# Process: Raster to Polygon
arcpy.AddMessage('Convert to polygon...')
arcpy.RasterToPolygon_conversion(depth_reclass,depth_reclass_poly,"NO_SIMPLIFY")

# Process: Add Field
arcpy.AddField_management(depth_reclass_poly,"DPTH","LONG")

# Process: Calculate Field
arcpy.CalculateField_management(depth_reclass_poly,"DPTH","!gridcode!","PYTHON_9.3")

# Process: Dissolve
arcpy.AddMessage('Dissolving...')
arcpy.Dissolve_management(depth_reclass_poly,depth_reclass_poly_d,"DPTH")

# Process: Delete Field
##DeleteField_management (in_table, drop_field) 
arcpy.DeleteField_management(depth_reclass_poly,"gridcode")

# Process: Add Field
arcpy.AddField_management(depth_reclass_poly_d,"DRANGE","TEXT")

# Process: Make Feature Layer
arcpy.MakeFeatureLayer_management(depth_reclass_poly_d,depth_reclass_layer)

for i in range(len(drs)):
	where_clause = "DPTH = " + str(i+1)
	expr = '"' + drs[i] + '"'

	# Process: Select Layer by Attribute
	arcpy.SelectLayerByAttribute_management(depth_reclass_layer,"NEW_SELECTION",where_clause)
	
	# Process: Calculate Field
	arcpy.CalculateField_management(depth_reclass_layer,"DRANGE",expr,"PYTHON_9.3","")

	# Process: Clear Selection
	arcpy.SelectLayerByAttribute_management(depth_reclass_layer,"CLEAR_SELECTION","")

# Add to map
nl = arcpy.mapping.Layer(depth_reclass_poly_d)
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()
