# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# SURFEL-slope.py
# Created on: 2019-11-13 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: SURFELslope <DEM><InputThreshold>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)
InputThreshold = arcpy.GetParameterAsText(1)
if InputThreshold == '#' or not InputThreshold:
    InputThreshold = "10" # provide a default value if unspecified
    
DEM = InputFeatureClass
arcpy.AddMessage('   DEM: ' + DEM)
th = InputThreshold
arcpy.AddMessage('   Threshold: ' + th)

# Local variables:
slope = arcpy.env.scratchWorkspace + os.sep + "slope"
slope_reclass = arcpy.env.scratchWorkspace + os.sep + "slope_reclass_raster"
slope_reclass_poly = arcpy.env.workspace + os.sep + "slope_reclass_poly"
slope_reclass_poly_d = arcpy.env.workspace + os.sep + "slope_reclass"

# Process: Slope (spatial analyst)
arcpy.AddMessage('Calculate Slope...')
outSlope=Slope(DEM,"DEGREE",1)
outSlope.save(slope)

# Process: Reclassify (spatial analyst)
arcpy.AddMessage('Reclassify...')
remap = RemapRange([[0,float(th)-0.000001,1],[float(th),90,2]])
outReclass = Reclassify(slope,"VALUE",remap)
outReclass.save(slope_reclass)

# Process: Raster to Polygon
arcpy.AddMessage('Convert to polygon...')
arcpy.RasterToPolygon_conversion(slope_reclass,slope_reclass_poly,"NO_SIMPLIFY")

# Process: Add Field
arcpy.AddField_management(slope_reclass_poly,"SLP","LONG")

# Process: Calculate Field
arcpy.CalculateField_management(slope_reclass_poly,"SLP",
						"!gridcode!",
						"PYTHON_9.3")
						
# Process: Dissolve
arcpy.AddMessage('Dissolving...')
arcpy.Dissolve_management(slope_reclass_poly,slope_reclass_poly_d,"SLP")

# Process: Delete Field
arcpy.DeleteField_management(slope_reclass_poly,"gridcode")

sys.exit()
