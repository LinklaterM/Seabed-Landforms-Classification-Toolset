# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# SURFEL-union-surfel.py
# Created on: 2019-11-14 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: SURFELunionsurfel <>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Local variables:
union_poly = arcpy.env.workspace + os.sep + "reclass_Union"
union_poly2 = arcpy.env.workspace + os.sep + "surf_elem_union"
slope = arcpy.env.workspace + os.sep + "slope_reclass"
vrm = arcpy.env.workspace + os.sep + "vrm_reclass"
finebpi = arcpy.env.workspace + os.sep + "finebpi_reclass"
broadbpi = arcpy.env.workspace + os.sep + "broadbpi_reclass"
#depth = arcpy.env.workspace + os.sep + "depth_reclass"

in_features = [slope, vrm, finebpi, broadbpi]
#in_features = [depth, slope, vrm, finebpi, broadbpi]

arcpy.AddMessage('   Union_poly: ' + union_poly2)

# Process: Union
arcpy.Union_analysis(in_features,union_poly,"NO_FID")

# Process: Select to get rid of zero vrm (ruggedness values)
arcpy.Select_analysis(union_poly,union_poly2,""""RUG" > 0""")

# Process: Delete
arcpy.Delete_management(union_poly)

sys.exit()

