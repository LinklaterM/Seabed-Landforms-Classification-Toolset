# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LANDFORMS-prelim-landforms.py
# Created on: 2020-06-15 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: LANDFORMSprelimlandforms <surf_elem><DEM><Rugg_thresh>
# Description: LANDFORMS step 6 prelim landforms - to review
#
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
Surf_elem = arcpy.GetParameterAsText(0)
DEM = arcpy.GetParameterAsText(1)
Rugg_thresh =  arcpy.GetParameterAsText(2)
if Rugg_thresh == '#' or not Rugg_thresh:
    Rugg_thresh = "0.0003" # provide a default value if unspecified
    
# Local variables:
sum_surfel = arcpy.env.workspace + os.sep + "sum_surfel"
prelim_landforms = arcpy.env.workspace + os.sep + "prelim_landforms"

# Write to config file
logfile = ''
for fl_all in os.listdir(Base_Dir):
	if fl_all.startswith("CurrentSession_Settings_LANDFORMS"):
		logfile = fl_all

if logfile:
	f = open(logfile,"a")
	s1 = 'Step4: \n'
	s2 = '	Ruggedness Threshold: ' + Rugg_thresh + ' \n'
	s = s1 + s2
	f.write(s)
	f.close()

# Check that working and scratch gdb's exist
arcpy.PREPcheckDB()

# Process: Call LANDFORMboundpoly (Stage1)
arcpy.AddMessage('LANDFORMS bounding polygon...')
arcpy.LANDboundpoly(Surf_elem)

# Process: Call LANDpolysoutcrop (Stage 2)
arcpy.AddMessage('LAND polys within rugose outcrops...')
arcpy.LANDpolysoutcrop(sum_surfel)

# Process: Call LANDrelabel(Stage 3)
arcpy.AddMessage('LAND relabel landforms...')
arcpy.LANDrelabel(sum_surfel)

# Call LANDflagnoise (Stage 4)
arcpy.AddMessage('LAND flag noise...')
arcpy.LANDflagnoise(DEM,Rugg_thresh)

# Process: Copy sum_surfel -> prelim_landforms
arcpy.Copy_management(sum_surfel,prelim_landforms)

# Prcoess: Remove sum_surfel
arcpy.Delete_management(sum_surfel)

# Process: Clear scratch.gdb
arcpy.env.workspace = Base_Dir + os.sep + "Scratch.gdb"
arcpy.AddMessage('Deleting Scratch ...')
fc_list = arcpy.ListFeatureClasses()
for fc in fc_list:
	arcpy.Delete_management(fc)

ds_list = arcpy.ListDatasets()
for ds in ds_list:
	arcpy.Delete_management(ds)

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"

# Add to map
nl = arcpy.mapping.Layer(prelim_landforms)
if os.path.exists(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "PrelimLandforms.lyr"):
	sym_lyr = arcpy.mapping.Layer(Tool_Dir + os.sep + "ColourSchemes" + os.sep + "PrelimLandforms.lyr")
	arcpy.mapping.UpdateLayer(df,nl,sym_lyr,True)
	
arcpy.mapping.AddLayer(df, nl, "AUTO_ARRANGE")

sys.exit()

