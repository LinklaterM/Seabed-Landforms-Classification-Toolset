# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LAND-ploys-outcrop.py
# Created on: 2020-06-16 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: LANDpolysoutcrop <reclass_union>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)

# Local variables:
sum_surfel_layer = "sum_surfel_layer"
study_area_Er_rug_outcrops = arcpy.env.workspace + os.sep + "study_area_Er_rug_outcrops"
study_area_Er_all_rug_classes = arcpy.env.workspace + os.sep + "study_area_Er_all_rug_classes"

# Process: Delete Fields
arcpy.DeleteField_management(InputFeatureClass,"WithinRug") 
arcpy.DeleteField_management(InputFeatureClass,"WithinAllR") 

# Process: Make Feature Layer
arcpy.AddMessage('Make Feature Layer...')
arcpy.MakeFeatureLayer_management(InputFeatureClass,sum_surfel_layer)

steps = [1,2]
for step in steps:
	arcpy.AddMessage(' ')
	arcpy.AddMessage('STEP ' + str(step) + '...')
	
	if step==1:
		field_name = "WithinRug"
		sa_Er = study_area_Er_rug_outcrops
		expr1 = "'Within rugose outcrops'"
	elif step==2:
		field_name = "WithinAllR"
		sa_Er = study_area_Er_all_rug_classes
		expr1 = "'Within all rugose classes'"

	
	# Process: Add Field
	arcpy.AddMessage('Add Field...')
	arcpy.AddField_management(InputFeatureClass,field_name,"TEXT","","","","","NULLABLE","NON_REQUIRED","")

	# Process: Select Layer by Location
	arcpy.AddMessage('Select Layer...')
	arcpy.SelectLayerByLocation_management(sum_surfel_layer,"WITHIN",sa_Er,"","NEW_SELECTION","NOT_INVERT")

	# Process: Calculate Field
	arcpy.AddMessage('Calculate Field...')
	arcpy.CalculateField_management(sum_surfel_layer,field_name,expr1,"PYTHON_9.3","")

	# Process: Select Layer by Attribute
	arcpy.AddMessage('Switch Selection...')
	arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"SWITCH_SELECTION","")

	# Process: Calculate Field
	arcpy.AddMessage('Calculate Field...')
	arcpy.CalculateField_management(sum_surfel_layer,field_name,"'Other'","PYTHON_9.3","")

	# Process: Clear Selection
	arcpy.AddMessage('Clear Selection...')
	arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"CLEAR_SELECTION","")


sys.exit()

