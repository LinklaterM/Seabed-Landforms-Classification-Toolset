# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# LAND-flag-noise.py
# Created on: 2020-07-01 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: LANDflagnoise <DEM><Threshold>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

tbx = Tool_Dir+ os.sep + \
				"btm-3.0-final" + os.sep + "toolbox" + os.sep + \
				"btm.pyt"
arcpy.ImportToolbox(tbx)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)
InputThreshold = arcpy.GetParameterAsText(1)
if InputThreshold == '#' or not InputThreshold:
    InputThreshold = "0.0003" # provide a default value if unspecified
    
DEM = InputFeatureClass
arcpy.AddMessage('   DEM: ' + DEM)
th = InputThreshold
arcpy.AddMessage('   Threshold: ' + th)

# Local variables:
sum_surfel = arcpy.env.workspace + os.sep + "sum_surfel"
vrm_reclass_single = arcpy.env.workspace + os.sep + "vrm_noise_corr"
landform_edits = arcpy.env.workspace + os.sep + "landform_edits"

vrm = arcpy.env.scratchWorkspace + os.sep + "vrm_nc"
vrm_reclass = arcpy.env.scratchWorkspace + os.sep + "vrm_noise_reclass"
vrm_reclass_poly = arcpy.env.scratchWorkspace + os.sep + "vrm_noise_rcl_poly"

sum_surfel_layer = "sum_surfel_layer"

###	STEP 1	##########################################
arcpy.AddMessage(' ')
arcpy.AddMessage('STEP 1...')

# Process: Terrain Ruggedness (Benthic Terrain Modeler)
arcpy.AddMessage('Calculate Ruggedness (VRM)...')
arcpy.terrainruggedness_btm(DEM,3,vrm)

# Process: Reclassify (spatial analyst)
arcpy.AddMessage('Reclassify...')
remap = RemapRange([[0,float(th),"NODATA"],[float(th),1,1]])   
outReclass = Reclassify(vrm,"VALUE",remap)
outReclass.save(vrm_reclass)

# Process: Raster to Polygon
arcpy.AddMessage('Convert to polygon...')
arcpy.RasterToPolygon_conversion(vrm_reclass,vrm_reclass_poly,"NO_SIMPLIFY","VALUE")

# Process: Mulitpart to Singlepart
arcpy.AddMessage('Multi to Single...')
arcpy.MultipartToSinglepart_management(vrm_reclass_poly, vrm_reclass_single)

###	STEP 2	##########################################
arcpy.AddMessage(' ')
arcpy.AddMessage('STEP 2...')

# Process: Add Field
arcpy.AddMessage('Add Field...')
arcpy.AddField_management(sum_surfel,"Noise","TEXT","","","","","NULLABLE","NON_REQUIRED","")

# Process: Make Feature Layer
arcpy.AddMessage('Make Feature Layer...')
arcpy.MakeFeatureLayer_management(sum_surfel,sum_surfel_layer)

# Process: Select Layer by Location
arcpy.AddMessage('Select Layer...')	
arcpy.SelectLayerByLocation_management(sum_surfel_layer,"INTERSECT",vrm_reclass_single,"","NEW_SELECTION","INVERT")

# Process: Select Layer by Attribute
arcpy.AddMessage('Select Layer by attributes...')
where_clause = "LAND_1 = 'Peaks' OR LAND_1 = 'Peaks REVIEW' OR LAND_1 = 'Reefs/Banks' OR LAND_1 = 'Reefs/Banks REVIEW' OR LAND_1 = 'Depressions and channels Rugose' OR LAND_1 = 'Depressions and channels Rugose REVIEW' OR LAND_1 = 'Scarps'"  
arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"SUBSET_SELECTION",where_clause)

# Process: Calculate Field
arcpy.AddMessage('Calculate Field...')
arcpy.CalculateField_management(sum_surfel_layer,"Noise","'Noise'","PYTHON_9.3","")

# Process: Select Layer by Attribute
arcpy.AddMessage('Switch Selection...')
arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"SWITCH_SELECTION","")

# Process: Calculate Field
arcpy.AddMessage('Calculate Field...')
arcpy.CalculateField_management(sum_surfel_layer,"Noise","'Other'","PYTHON_9.3","")

# Process: Clear Selection
arcpy.AddMessage('Clear Selection...')
arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"CLEAR_SELECTION","")

###	STEP 3	##########################################
arcpy.AddMessage(' ')
arcpy.AddMessage('STEP 3...')

# Process: Add Field
arcpy.AddMessage('Add Field...')
arcpy.AddField_management(sum_surfel,"LAND_2","TEXT","","","100","","NULLABLE","NON_REQUIRED","")

# Process: Calculate Field
arcpy.AddMessage('Calculate Field...')
arcpy.CalculateField_management(sum_surfel,"LAND_2","!LAND_1!","PYTHON_9.3","")

# Process: Make Feature Layer
arcpy.AddMessage('Make Feature Layer...')
arcpy.MakeFeatureLayer_management(sum_surfel,sum_surfel_layer)

# Process: Select Layer by Attribute
arcpy.AddMessage('Select Layer by attributes...')
where_clause = "Noise = 'Noise'"
arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"NEW_SELECTION",where_clause)

# Process: Calculate Field
arcpy.AddMessage('Calculate Field...')
arcpy.CalculateField_management(sum_surfel_layer,"LAND_2","'[Noise]'","PYTHON_9.3","")

# Process: Clear Selection
arcpy.AddMessage('Clear Selection...')
arcpy.SelectLayerByAttribute_management(sum_surfel_layer,"CLEAR_SELECTION","")

###	STEP 4	##########################################
arcpy.AddMessage(' ')
arcpy.AddMessage('STEP 4...')

# Process: Add Field
arcpy.AddMessage('Add Field...')
arcpy.AddField_management(sum_surfel,"PrelimLand","TEXT","","","100","","NULLABLE","NON_REQUIRED","")

# Process: Calculate Field
arcpy.AddMessage('Calculate Field...')
arcpy.CalculateField_management(sum_surfel_layer,"PrelimLand","!LAND_2!","PYTHON_9.3","")


# Process: Add Field
arcpy.AddMessage('Add Field...')
arcpy.AddField_management(sum_surfel,"CONFID","TEXT","","","","","NULLABLE","NON_REQUIRED","")

sys.exit()
