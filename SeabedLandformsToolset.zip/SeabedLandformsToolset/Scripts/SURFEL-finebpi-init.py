# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# SURFEL-finebpi-init.py
# Created on: 2019-11-14 13:37:37.00000
# Last modified: 2023-06-28
# 
# Usage: SURFELfinebpiinit <DEM><WinSize>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
DEM = arcpy.GetParameterAsText(0)
WinSize = arcpy.GetParameterAsText(1)
if WinSize == '#' or not WinSize:
    WinSize = "27" # provide a default value if unspecified

arcpy.AddMessage('   DEM: ' + DEM)

# Local variables:
bpi_r = arcpy.env.scratchWorkspace + os.sep + "finebpi_r"
bpi = arcpy.env.scratchWorkspace + os.sep + "finebpi"
ana_win = "Rectangle " + WinSize + " " + WinSize + " CELL"

# Process: Slope Postion FineBPI
# From Geomorphometry & Gradient Metrics Toolbox V2 (Jeff Evans and Jim Oakleaf)
arcpy.AddMessage('Calculate Fine BPI...')
arcpy.AddMessage('Window Size: ' + WinSize)
meanTmp = FocalStatistics(DEM,ana_win,"MEAN")
bpi_r = DEM - meanTmp

# Process: Standardise
bpi_meanRes = arcpy.GetRasterProperties_management(bpi_r,"MEAN")
bpi_mean = float(bpi_meanRes.getOutput(0))
arcpy.AddMessage('bpi_mean: ' + str(bpi_mean))

bpi_stdRes = arcpy.GetRasterProperties_management(bpi_r,"STD")
bpi_std = float(bpi_stdRes.getOutput(0))
arcpy.AddMessage('bpi_std: ' + str(bpi_std))

outRaster = Int(Plus(Times(Divide(
            Minus(bpi_r, bpi_mean), bpi_std), 100), 0.5))
outRaster.save(bpi)

# Process: Find range of raster
bpi_maxRes = arcpy.GetRasterProperties_management(bpi,"MAXIMUM")
bpi_max = int(bpi_maxRes.getOutput(0))
arcpy.AddMessage('bpi_max: ' + str(bpi_max))

bpi_minRes = arcpy.GetRasterProperties_management(bpi,"MINIMUM")
bpi_min = int(bpi_minRes.getOutput(0))
arcpy.AddMessage('bpi_min: ' + str(bpi_min))

sys.exit()
