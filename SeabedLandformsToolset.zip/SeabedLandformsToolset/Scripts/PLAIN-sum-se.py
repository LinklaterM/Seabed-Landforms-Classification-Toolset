# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# PLAIN-surfel.py
# Created on: 2019-11-14 13:37:37.00000
# Last modified: 2023-06-29
# 
# Usage: PLAINsumse <reclass_union>
# Description: 
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy, os
from arcpy.sa import *

# Check out any necessary licenses
arcpy.CheckOutExtension("spatial")

# Setting OverWriteOutput to True allows geoprocessing tools to overwrite
#    the output if it already exists.
arcpy.env.overwriteOutput = True

# Set Geoprocessing environments
mxd = arcpy.mapping.MapDocument("CURRENT")
df = mxd.activeDataFrame
ep = mxd.filePath
ebp = ep.split("\\")
Base_Dir = "\\".join(ebp[0:len(ebp)-1])

arcpy.AddMessage('   Base_Dir: ' + Base_Dir)

ept = os.path.realpath(__file__)
ebpt = ept.split("\\")
Tool_Dir = "\\".join(ebpt[0:len(ebpt)-2])

arcpy.env.workspace = Base_Dir + os.sep + "Working.gdb"
arcpy.env.scratchWorkspace = Base_Dir + os.sep + "Scratch.gdb"

# Load required toolboxes
arcpy.ImportToolbox(Tool_Dir + os.sep + "Seabed Landforms Classification.tbx")
arcpy.AddMessage('   Tool_Dir: ' + Tool_Dir)

# Script arguments
InputFeatureClass = arcpy.GetParameterAsText(0)

union_poly = InputFeatureClass
arcpy.AddMessage('   reclass_Union: ' + union_poly)

# Local variables
expression = "myCalc(!SURF_EL!)"
codeblock = """def myCalc(old):
	if old == "FS High":
		return "Localised high"
	elif old == "FS Low":
		return "Localised low"
	elif old == "BS High":
		return "Plain high"
	elif old == "BS Low":
		return "Plain low"
	elif old == "Plane":
		return "Plain flat"
	else:
		return "" """

# Process: Add Field
arcpy.AddField_management(union_poly,"PLAIN","TEXT")

# Process: Calculate Field
arcpy.CalculateField_management(union_poly,"PLAIN",expression,"PYTHON_9.3",codeblock)

sys.exit()

